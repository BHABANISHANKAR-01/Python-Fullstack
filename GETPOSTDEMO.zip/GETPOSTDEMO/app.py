from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    """
    Render the homepage with a form to submit the name.
    """
    return render_template('index.html')

@app.route('/greet', methods=['POST'])
def greet():
    """
    Handle the POST request to display a personalized greeting.
    """
    name = request.form.get('name')  # Retrieve the 'name' field from the form
    if not name:
        return "Please enter a name!", 400
    return render_template('greeting.html', name=name)

if __name__ == "__main__":
    app.run(port=8834, debug=True)
